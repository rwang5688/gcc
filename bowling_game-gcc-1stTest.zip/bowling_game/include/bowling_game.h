// bowling_game.h
#ifndef BOWLING_GAME_H_
#define BOWLING_GAME_H_

class Game {
public:
	int Score();
};

#endif  // BOWLING_GAME_H_