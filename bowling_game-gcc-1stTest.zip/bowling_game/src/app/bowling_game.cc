// bowling_game.cc

#include "bowling_game.h"

int Game::Score(){
	return 0;
}