// bowling_game.cc

#include "bowling_game.h"

void Game::Roll(int pins){
	score_ += pins;
}

int Game::Score(){
	return score_;
}
