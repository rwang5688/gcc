// bowling_game.cc

#include "bowling_game.h"

void Game::Roll(int pins){
}

int Game::Score(){
	return 0;
}
